package registradores;

public class Uc {
  public int i;
  public int eax, ebx;
  public String instrucao;


}