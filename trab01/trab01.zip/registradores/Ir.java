package registradores;

public class Ir {
    public String instrucao;
}