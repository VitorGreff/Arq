package registradores;

public class Pc {
    public int enderecoInstrucao;
}