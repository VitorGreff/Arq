package registradores;

public class Mbr {
    public String instrucao;
}