package registradores;

public class Mar {
    public int enderecoInstrucao;
}